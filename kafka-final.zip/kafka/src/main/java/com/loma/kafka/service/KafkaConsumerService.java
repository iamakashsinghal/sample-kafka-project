package com.loma.kafka.service;

import org.springframework.kafka.annotation.KafkaListener;

public class KafkaConsumerService {
    @KafkaListener(topics = "#{kafka.topic.name}", groupId = "group_id")
    public void listen(String message) {
        // Process the message
        System.out.println("Received Message: " + message);
    }
}
