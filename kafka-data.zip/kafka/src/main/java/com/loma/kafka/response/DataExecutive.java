package com.loma.kafka.response;
import com.loma.kafka.dao.Case;
import java.util.List;
/**
 * @author : Akash-loma
 * @project: kafka-CMS
 * @mailto : akash.singhal@lomatechnology.com
 * @created : 2024/8/14
 **/
public class DataExecutive {
    private String id;
    private boolean available;
    private boolean onBreak;
    private List<String> expertise; // List of case types the executive is expert in

    public DataExecutive(String id, List<String> expertise) {
        this.id = id;
        this.expertise = expertise;
        this.available = true;
        this.onBreak = false;
    }

    public String getId() {
        return id;
    }

    public boolean isAvailable() {
        return available && !onBreak;
    }

    public boolean isExpertIn(String caseType) {
        return expertise.contains(caseType);
    }

    public void assignCase(Case caseToAssign) {
        // Handle case assignment logic
        System.out.println("Case " + caseToAssign.getId() + " assigned to Executive " + id);
    }

    public void takeBreak() {
        this.onBreak = true;
    }

    public void resumeWork() {
        this.onBreak = false;
    }

    public void setAvailability(boolean available) {
        this.available = available;
    }
}
