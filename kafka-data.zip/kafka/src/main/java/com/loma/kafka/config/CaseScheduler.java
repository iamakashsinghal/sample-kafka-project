package com.loma.kafka.config;
import com.loma.kafka.dao.Case;
import com.loma.kafka.response.DataExecutive;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
/**
 * @author : Akash-loma
 * @project: kafka-CMS
 * @mailto : akash.singhal@lomatechnology.com
 * @created : 2024/8/14
 **/
@Component
public class CaseScheduler {

    private Queue<Case> caseQueue = new LinkedList<>();
    private List<DataExecutive> dataExecutives = new LinkedList<>();

    public void addCase(Case caseToAdd) {
        caseQueue.add(caseToAdd);
    }

    public void addDataExecutive(DataExecutive executive) {
        dataExecutives.add(executive);
    }

    public void assignCases() {
        while (!caseQueue.isEmpty()) {
            Case caseToAssign = caseQueue.poll();
            DataExecutive executive = findAvailableExecutive(caseToAssign.getCase_type_id());

            if (executive != null) {
                executive.assignCase(caseToAssign);
                System.out.println("Case " + caseToAssign.getCase_id() + " assigned to Executive " + executive.getId());
            } else {
                System.out.println("No available Data Executive for Case " + caseToAssign.getCase_id());
                caseQueue.add(caseToAssign); // Re-add case to queue
                break; // Exit the loop to wait for executives to become available
            }
        }
    }

    private DataExecutive findAvailableExecutive(String caseType) {
        for (DataExecutive executive : dataExecutives) {
            if (executive.isAvailable() && executive.isExpertIn(caseType)) {
                return executive;
            }
        }
        return null;
    }
}