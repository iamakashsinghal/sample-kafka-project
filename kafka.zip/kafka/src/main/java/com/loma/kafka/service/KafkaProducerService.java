package com.loma.kafka.service;

import com.loma.kafka.payload.KafkaPayload;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducerService {

    private final KafkaTemplate<String, KafkaPayload> kafkaTemplate;

    public KafkaProducerService(KafkaTemplate<String, KafkaPayload> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(String topic, KafkaPayload payload) {
        kafkaTemplate.send(topic, payload);
    }
}