package com.loma.kafka.controller;

import com.loma.kafka.response.KafkaResponse;
import com.loma.kafka.service.KafkaConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/kafka")
public class KafkaConsumerController {

//    @Autowired
//    private KafkaConsumerService kafkaConsumerService;
//
//    @GetMapping("/consumed-messages")
//    public List<KafkaResponse> getConsumedMessages() {
//        return kafkaConsumerService.getConsumedMessages();
//    }
}
