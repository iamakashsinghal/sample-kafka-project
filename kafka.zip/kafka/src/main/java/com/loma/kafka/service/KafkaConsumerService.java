package com.loma.kafka.service;

import com.loma.kafka.payload.KafkaPayload;
import com.loma.kafka.response.KafkaResponse;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class KafkaConsumerService {

    @KafkaListener(topics = "world", groupId = "my-group")
    public KafkaResponse consume(KafkaPayload message) {
        System.out.println("Received Message: " + message);

        KafkaResponse response = new KafkaResponse();
        response.setVendorCode(message.getVendorCode());
        response.setCaseId(message.getCaseId());
        response.setRequestedTime(message.getRequestedTime().toString());
        response.setCaseTypeId(message.getCaseTypeId());
        response.setTypeName(message.getTypeName());
        response.setFields(message.getFields());
        response.setRemark("Success"); // Update based on your logic
        response.setCaseStatus("pending"); // Update based on your logic
        response.setActionStatus("NA"); // Update based on your logic
        response.setSendTime(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        // Process or store the response as needed
        System.out.println("Processed Response: " + response);

        return response;
    }
}