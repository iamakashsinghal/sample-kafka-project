//package com.loma.kafka.dao;
//
//import java.time.LocalDateTime;
//import java.util.Map;
//
//public class KafkaMessage {
//    private String vendorCode;
//    private String caseId;
//    private LocalDateTime requestedTime;
//    private String caseTypeId;
//    private String typeName;
//    private Map<String, String> fields;
//
//    // Getters and Setters
//    public String getVendorCode() {
//        return vendorCode;
//    }
//
//    public void setVendorCode(String vendorCode) {
//        this.vendorCode = vendorCode;
//    }
//
//    public String getCaseId() {
//        return caseId;
//    }
//
//    public void setCaseId(String caseId) {
//        this.caseId = caseId;
//    }
//
//    public LocalDateTime getRequestedTime() {
//        return requestedTime;
//    }
//
//    public void setRequestedTime(LocalDateTime requestedTime) {
//        this.requestedTime = requestedTime;
//    }
//
//    public String getCaseTypeId() {
//        return caseTypeId;
//    }
//
//    public void setCaseTypeId(String caseTypeId) {
//        this.caseTypeId = caseTypeId;
//    }
//
//    public String getTypeName() {
//        return typeName;
//    }
//
//    public void setTypeName(String typeName) {
//        this.typeName = typeName;
//    }
//
//    public Map<String, String> getFields() {
//        return fields;
//    }
//
//    public void setFields(Map<String, String> fields) {
//        this.fields = fields;
//    }
//}