package com.loma.kafka.service;

import com.loma.kafka.payload.DataExecutive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CaseAssignmentService {

    @Autowired
    private NotificationService notificationService;

    public void handleCase(String caseDetails, String applicationId) {
        // Assuming you have logic to parse the message and extract case type, ID, etc.
        String caseType = extractCaseType(caseDetails); // Extract case type from the message
        DataExecutive assignedExecutive = assignCase(caseType, getAvailableExecutives(applicationId));

        notificationService.notifyExecutive(assignedExecutive, caseDetails);
    }

    private String extractCaseType(String caseDetails) {
        // Implement the logic to extract case type from the message
        return "DEPOSIT"; // Simplified example
    }

    private List<DataExecutive> getAvailableExecutives(String applicationId) {
        // Implement the logic to retrieve available Data Executives for the application
        return List.of(new DataExecutive("akash.singhal@lomatechnology.com"),
                new DataExecutive("akash.singhal@lomatechnology.com"));
    }

    private DataExecutive assignCase(String caseType, List<DataExecutive> availableExecutives) {
        // Implement your case assignment logic here
        // This can include checking executive availability, workload, expertise, etc.
        return availableExecutives.get(0); // Simplified example
    }
}