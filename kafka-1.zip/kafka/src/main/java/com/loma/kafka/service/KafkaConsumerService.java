package com.loma.kafka.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {

    @Autowired
    private CaseAssignmentService caseAssignmentService;

    @KafkaListener(topics = "app1-cases", groupId = "my-group")
    public void consumeApp1Cases(String message) {
        System.out.println("Received case for App1: " + message);
        caseAssignmentService.handleCase(message, "app1");
    }

    @KafkaListener(topics = "app2-cases", groupId = "my-group")
    public void consumeApp2Cases(String message) {
        System.out.println("Received case for App2: " + message);
        caseAssignmentService.handleCase(message, "app2");
    }

    // Add more listeners for other applications as needed
}