package com.loma.kafka.config;

import com.loma.kafka.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CaseManagementRunner implements CommandLineRunner {

    @Autowired
    private KafkaProducerService kafkaProducerService;

    @Override
    public void run(String... args) throws Exception {
        // Simulate sending a case event
        String caseEvent = "{ \"caseId\": \"12345\", \"caseType\": \"DEPOSIT\", \"customerDetails\": \"John Doe\" }";
        kafkaProducerService.sendCaseEvent("app1-cases", caseEvent);

        // Simulate another case event for a different application
        String anotherCaseEvent = "{ \"caseId\": \"67890\", \"caseType\": \"WITHDRAWAL\", \"customerDetails\": \"Jane Doe\" }";
        kafkaProducerService.sendCaseEvent("app2-cases", anotherCaseEvent);
    }
}
