package com.loma.kafka.service;

import com.loma.kafka.payload.DataExecutive;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    public void notifyExecutive(DataExecutive executive, String caseDetails) {
        String subject = "New Case Assigned";
        String body = "You have been assigned a new case: " + caseDetails;
        sendEmail(executive.getEmail(), subject, body);
    }

    private void sendEmail(String email, String subject, String body) {
        // Implement email sending logic
        System.out.println("Sending email to " + email + ": " + subject + " - " + body);
    }
}