package com.loma.kafka.controller;

import com.loma.kafka.payload.KafkaPayload;
import com.loma.kafka.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/kafka")
public class KafkaController {

    @Autowired
    private KafkaProducerService kafkaProducerService;

    @PostMapping("/send")
    public ResponseEntity<String> sendMessage(@RequestParam String domainName, @RequestBody KafkaPayload payload) {
        kafkaProducerService.sendMessage(domainName, payload);
        return ResponseEntity.ok("Message sent successfully!");
    }
}