package com.loma.kafka.payload;

public class DataExecutive {
    private String email;

    public DataExecutive(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
}
